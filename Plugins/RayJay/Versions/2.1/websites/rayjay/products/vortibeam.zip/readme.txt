Product Name: Vortibeam

==== Installation ====
To install, add the plugin to your plugins folder in your SCHEMA gamemode.

==== How To Make Vortigaunts Spawn With The Vortibeam ====
(This will have a player start with the Vortibeam every time they spawn)

1. Open sv_vortibeam.lua found in vortibeam/plugin/libraries/.
2. Add this line for each faction you wish to spawn with the Vortibeam weapon: PLUGIN.vortibeam:AddBeam(FACTION_ID);
3. Replace FACTION_ID with the ID of the faction (found at the bottom in /schema/factions/faction_name.lua).