Product Name: Thermals

==== Installation ====
To install, add the plugin to your plugins folder in your SCHEMA gamemode.