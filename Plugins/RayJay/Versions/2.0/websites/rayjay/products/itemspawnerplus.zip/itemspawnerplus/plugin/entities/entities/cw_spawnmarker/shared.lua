DEFINE_BASECLASS("base_gmodentity");

ENT.Type			= "anim";

ENT.PrintName		= "Spawn Marker";
ENT.Author			= "RJ";

ENT.PhysgunDisabled = true;
ENT.Spawnable		= true;
ENT.AdminSpawnable	= true;