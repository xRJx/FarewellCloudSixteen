local PLUGIN = PLUGIN;

--The further down the list you go, the more unlikely it is to spawn.
--Rarities List:
--Abundant
--Common
--Uncommon
--Valuable
--Rare
--Legendary

PLUGIN.rarities = Clockwork.kernel:NewLibrary("Rarities");

function PLUGIN.rarities:AddRarity(item, value)
	local ITEM = Clockwork.item:FindByID(item);
	
	ITEM.value = value;
end;

PLUGIN.rarities:AddRarity("Suitcase", "Abundant");