Product Name: ItemSpawnerPlus

====Installation====
To install, add the plugin to your plugins folder in your SCHEMA gamemode.
IMPORTANT: Be sure to NOT have the free version of the Item Spawner plugin installed.
ALSO IMPORTANT: For installation on Clockwork versions below 0.87, contact support@exiguous-productions.com.

====Rarities====
The further down the list you go, the more unlikely it is to spawn.
Abundant
Common
Uncommon
Valuable
Rare
Legendary

====How To Add An Item To Be Spawned====
1. Open sh_rarities.lua found in itemspawnerplus/plugin/libraries/.
2. Add this line for each item you wish to have a rarity with: PLUGIN.rarities:AddRarity("item_id1", "rarity");
3. Replace item_id1 with the ID of the item to assign a rarity with.
4. Replace rarity with a rarity from the above list (capitalization is important).

====Usage (Requires Super Admin)====
To add an item spawn, look at where you want to add an item spawn location, then type /ItemSpawnAdd
To use the Item Spawn ESP, open your Settings then check the "Enable item spawn ESP" box under the "Framework" section.

====Modifications (Requires Basic Lua knowledge)====
----Changing The Spawn Rate----
1. Open sh_hooks.lua.
2. Read the commented text on how to change the spawn rate.

----Changing The Rarities----
-Coming Soon-