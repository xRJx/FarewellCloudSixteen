local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Zip Tie Blueprint";
BLUEPRINT.model = "models/items/crossbowrounds.mdl";
BLUEPRINT.weight = 0.1;

BLUEPRINT.category = "Miscellaneous Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Cables";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"cables"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"cables"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"zip_tie"
	}
end;

BLUEPRINT:Register();