Product Name: Crafting

==== Installation ====
To install, add the plugin to your plugins folder in your SCHEMA gamemode.

==== How To Hide The Business Menu ====
1. Join your Clockwork server.
2. Open your Systems menu (you must be a Super Admin).
3. Open your Clockwork Config menu.
4. Find the "Business hidden" configuration.
5. Tick the "On" checkbox under the "Business hidden" configuration.