local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Grenade Blueprint";
BLUEPRINT.model = "models/weapons/w_grenade.mdl";
BLUEPRINT.weight = 0.5;

BLUEPRINT.category = "Explosive Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx2 Gunpowder \nx2 Scrap Metal \nx1 Scrap Electronics";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		{"gunpowder", 2,},
		{"scrap_metal", 2},
		"scrap_electronics"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		{"gunpowder", 2},
		{"scrap_metal", 2},
		"scrap_electronics"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"weapon_frag"
	}
end;

BLUEPRINT:Register();