local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Reclaimed Metal Blueprint";
BLUEPRINT.model = "models/props_lab/pipesystem03a.mdl";
BLUEPRINT.weight = 1;

BLUEPRINT.category = "Metal Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx3 Scrap Metal";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		{"scrap_metal", 3}
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		{"scrap_metal", 3}
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"reclaimed_metal"
	}
end;

BLUEPRINT:Register();