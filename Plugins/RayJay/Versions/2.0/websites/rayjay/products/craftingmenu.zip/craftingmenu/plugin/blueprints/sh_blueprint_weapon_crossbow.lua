local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Crossbow Blueprint";
BLUEPRINT.model = "models/crossbow/w_crossbow.mdl";
BLUEPRINT.weight = 1.5;

BLUEPRINT.category = "Weapon Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx2 Cables \nx2 Scrap Metal \nx1 Wood \nx1 Energy Cell \nx1 Bottle \nx1 Refined Metal \nx1 Scrap Electronics";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		{"cables", 2},
		{"scrap_metal", 2},
		"wood",
		"energy_cell",
		"bottle",
		"refined_metal",
		"scrap_electronics"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		{"cables", 2},
		{"scrap_metal", 2},
		"energy_cell",
		"wood",
		"bottle",
		"refined_metal",
		"scrap_electronics"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"weapon_crossbow"
	}
end;

BLUEPRINT:Register();