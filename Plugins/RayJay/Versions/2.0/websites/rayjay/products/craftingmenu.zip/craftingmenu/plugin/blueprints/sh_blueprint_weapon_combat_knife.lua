local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Combat Knife Blueprint";
BLUEPRINT.model = "models/weapons/w_knife_t.mdl";
BLUEPRINT.weight = 1;

BLUEPRINT.category = "Weapon Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Knife \nx1 Rock";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"knife",
		"rock"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"knife",
		"rock"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"weapon_knife"
	}
end;

BLUEPRINT:Register();