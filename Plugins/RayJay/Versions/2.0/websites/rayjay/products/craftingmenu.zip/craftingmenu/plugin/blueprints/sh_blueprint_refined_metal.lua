local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Refined Metal Blueprint";
BLUEPRINT.model = "models/gibs/metal_gib2.mdl";
BLUEPRINT.weight = 2;

BLUEPRINT.category = "Metal Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx3 Reclaimed Metal";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		{"reclaimed_metal", 3}
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		{"reclaimed_metal", 3}
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		{"refined_metal", 2}
	}
end;

BLUEPRINT:Register();