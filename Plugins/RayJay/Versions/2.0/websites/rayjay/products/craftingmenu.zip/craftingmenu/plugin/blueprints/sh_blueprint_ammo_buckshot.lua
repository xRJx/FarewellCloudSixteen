local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Shotgun Shells Blueprint";
BLUEPRINT.model = "models/items/boxbuckshot.mdl";
BLUEPRINT.weight = 1;

BLUEPRINT.category = "Ammunition Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Bullet Casings \nx1 Scrap Metal \nx1 Gunpowder \nx1 Plastic";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"bullet_casings",
		"scrap_metal",
		"gunpowder",
		"plastic"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"bullet_casings",
		"scrap_metal",
		"gunpowder",
		"plastic"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"ammo_buckshot"
	}
end;

BLUEPRINT:Register();