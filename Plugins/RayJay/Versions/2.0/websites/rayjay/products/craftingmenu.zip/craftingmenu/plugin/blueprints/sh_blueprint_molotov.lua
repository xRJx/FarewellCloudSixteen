/**
local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Molotov Blueprint";
BLUEPRINT.model = "";
BLUEPRINT.weight = 0.5;

BLUEPRINT.category = "Explosive Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Bottle \nx1 Petrol \nx1 Cloth";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"Bottle",
		"Petrol",
		"Cloth"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"Bottle",
		"Petrol",
		"Cloth"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"Molotov"
	}
end;

BLUEPRINT:Register();
**/