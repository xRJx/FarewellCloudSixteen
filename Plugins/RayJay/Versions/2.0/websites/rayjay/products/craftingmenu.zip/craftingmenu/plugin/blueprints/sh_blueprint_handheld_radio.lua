local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Handheld Radio Blueprint";
BLUEPRINT.model = "models/deadbodies/dead_male_civilian_radio.mdl";
BLUEPRINT.weight = 0.5;

BLUEPRINT.category = "Miscellaneous Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Refined Electronics \nx1 Refined Metal \nx1 Scrap Metal \nx1 Energy Cell";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"refined_electronics",
		"refined_metal",
		"scrap_metal",
		"energy_cell"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"refined_electronics",
		"refined_metal",
		"scrap_metal",
		"energy_cell"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"handheld_radio"
	}
end;

BLUEPRINT:Register();