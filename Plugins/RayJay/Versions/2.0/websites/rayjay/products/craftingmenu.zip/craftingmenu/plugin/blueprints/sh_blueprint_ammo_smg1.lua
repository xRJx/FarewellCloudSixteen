local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "SMG Ammo Blueprint";
BLUEPRINT.model = "models/items/boxmrounds.mdl";
BLUEPRINT.weight = 2;

BLUEPRINT.category = "Ammunition Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx2 Bullet casings \nx2 Gunpowder \nx2 Refined metal";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		{"bullet_casings", 2},
		{"gunpowder", 2},
		{"refined_metal", 2}
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		{"bullet_casings", 2},
		{"gunpowder", 2},
		{"refined_metal", 2}
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"ammo_smg1"
	}
end;

BLUEPRINT:Register();