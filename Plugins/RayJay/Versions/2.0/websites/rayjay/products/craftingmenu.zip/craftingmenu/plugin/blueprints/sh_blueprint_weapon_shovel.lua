/**
local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Shovel Blueprint";
BLUEPRINT.model = "";
BLUEPRINT.weight = 2;

BLUEPRINT.category = "Weapon Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Wooden Pole \nx1 Refined Metal";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"wooden_pole",
		"refined_metal"
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"wooden_pole",
		"refined_metal"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"shovel"
	}
end;

BLUEPRINT:Register();
**/