local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Breach Blueprint";
BLUEPRINT.model = "models/props_wasteland/prison_padlock001a.mdl";
BLUEPRINT.weight = 1;

BLUEPRINT.category = "Explosive Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx3 Gunpowder \nx1 Cables \nx1 Refined Electronics \nx1 Energy Cell \nx1 Cloth";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		{"gunpowder", 3},
		"cables",
		"refined_electronics",
		"energy_cell",
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		{"gunpowder", 3},
		"cables",
		"refined_electronics",
		"energy_cell",
		"cloth"
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"breach"
	}
end;

BLUEPRINT:Register();