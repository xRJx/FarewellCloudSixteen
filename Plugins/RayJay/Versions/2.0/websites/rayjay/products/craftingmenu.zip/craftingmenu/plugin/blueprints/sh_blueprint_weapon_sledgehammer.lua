/**
local BLUEPRINT = Clockwork.item:New("blueprint_base");

BLUEPRINT.name = "Sledgehammer Blueprint";
BLUEPRINT.model = "";
BLUEPRINT.weight = 2.5;

BLUEPRINT.category = "Weapon Blueprints"
BLUEPRINT.crafting = true;
BLUEPRINT.description = "Requirements: \nx1 Wooden pole \nx2 Refined metal";

-- A function to check for the required materials for a craft.
function BLUEPRINT:HasMaterials(player)
	return
	{
		"wooden_pole",
		{"refined_metal", 2}
	}
end;

-- A function to take the required materials for a craft.
function BLUEPRINT:TakeMaterials(player)
	return
	{
		"wooden_pole",
		{"refined_metal", 2}
	}
end;

-- A function to give a player a crafted item.
function BLUEPRINT:GiveCraft(player)
	return
	{
		"sledgehammer"
	}
end;

BLUEPRINT:Register();
**/