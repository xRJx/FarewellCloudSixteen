<?php
/*
local PLUGIN = PLUGIN;

function PLUGIN:PlayerThink(player, curTime, infoTable)
	PLUGIN:HandleThermalGoggles(player);
end;

function PLUGIN:HandleThermalGoggles(player)
	local thermalGoggles = player:GetWeapon("cw_thermal_goggles");
	
	if (IsValid(thermalGoggles) and thermalGoggles:IsActivated() and player:Alive() and !player:IsRagdolled()) then
		player:SetSharedVar("thermalsActive", true);
	else
		player:SetSharedVar("thermalsActive", false);
	end;
end;
*/
?>